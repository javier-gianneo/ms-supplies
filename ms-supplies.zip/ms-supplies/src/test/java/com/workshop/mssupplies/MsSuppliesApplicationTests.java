package com.workshop.mssupplies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsSuppliesApplicationTests {

	@Test
	void contextLoads() {
	}

}
