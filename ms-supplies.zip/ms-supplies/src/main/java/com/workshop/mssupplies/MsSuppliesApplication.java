package com.workshop.mssupplies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsSuppliesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsSuppliesApplication.class, args);
	}

}
